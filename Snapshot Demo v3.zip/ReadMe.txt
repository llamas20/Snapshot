To run on Windows:  Open Snapshot 1.0 -> Open Snapshot (Windows 1.0) -> Open the "Photos" file.

To run on Mac:  Open _MACOSX

NOTE:  The Credits button on the menu page does not open the credits.  Rather, it takes you directly to level 2.  Credits are on their way!
NOTE:  There are only 2 levels in the demo.


After having completed the game, please go to "https://tinyurl.com/snapshot-playtest-questions" and fill out the form.

Tutorial:

The game is one where you use a photo editor to "fix" the various pictures for the levels.

On the left-hand column, from top to bottom, you have your paint bucket, move layer in scene,
flip layer horizontally (about y axis), flip layer vertically (about x axis), and rotate tools.

On the right-hand column are the layer controls.  You are able to move layers up and down 
the hierarchy to hide them behind other layers, and a button to hide layers entirely, making them invisible.

The level is over when you have made the picture "normal" again.  Note that the UI is mostly placeholder at this point, so please don't judge it.

